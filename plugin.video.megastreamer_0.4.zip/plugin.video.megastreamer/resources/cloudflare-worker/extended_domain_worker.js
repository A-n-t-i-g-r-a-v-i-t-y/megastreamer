/**
 * MegaStreamer Extended Domain Cloudflare Worker
 * 
 * An advanced, optimized, and secure reverse proxy built specifically for 
 * MegaStreamer. It routes streaming chunk requests through Cloudflare's 
 * global edge network, dynamically rotating outbound IPs.
 * 
 * Extended Security & Reliability Features:
 * - Smart Bot Filtering: Serves the premium dashboard instead of 400 Bad Request 
 *   for invalid paths. This completely cleans up the Cloudflare 4xx analytics.
 * - CORS & Preflight Support: Correctly answers OPTIONS requests for browser-based compatibility.
 * - Extended Host Whitelist: Supports all Mega.nz userstorage and API endpoints (.co.nz and .nz).
 */

export default {
  async fetch(request, env, ctx) {
    const urlObj = new URL(request.url);
    
    // Handle CORS Preflight requests (OPTIONS method)
    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
          "Access-Control-Allow-Headers": "Range, User-Agent, Cache-Control",
          "Access-Control-Max-Age": "86400"
        }
      });
    }

    // Extract target URL from pathname (strip leading slash)
    let targetUrlStr = urlObj.pathname.substring(1) + urlObj.search;

    // Decode target URL if it is URL-encoded
    try {
      if (targetUrlStr.startsWith("http%3A") || targetUrlStr.startsWith("https%3A")) {
        targetUrlStr = decodeURIComponent(targetUrlStr);
      }
    } catch (e) {}

    // Serve a stunning premium HTML status page if no target URL is provided
    if (!targetUrlStr || targetUrlStr === "robots.txt") {
      if (targetUrlStr === "robots.txt") {
        return new Response("User-agent: *\nDisallow: /", {
          headers: { "Content-Type": "text/plain" }
        });
      }
      return new Response(getDashboardHTML(urlObj.origin), {
        headers: { "Content-Type": "text/html; charset=utf-8" }
      });
    }

    // Constraint: Only allow GET and HEAD requests for proxying
    if (request.method !== "GET" && request.method !== "HEAD") {
      return new Response("HTTP Method Not Allowed", { status: 405 });
    }

    // Attempt to parse destination URL
    let targetUrl;
    try {
      // Validate that it looks like a full URL
      if (!targetUrlStr.startsWith("http://") && !targetUrlStr.startsWith("https://")) {
        throw new Error("Invalid URL protocol");
      }
      targetUrl = new URL(targetUrlStr);
    } catch (e) {
      // Gracefully serve the premium dashboard instead of returning a 400 Bad Request.
      // This successfully filters out random bot requests (e.g. /wp-login.php, /favicon.ico) from the 4xx logs.
      return new Response(getDashboardHTML(urlObj.origin), {
        headers: { "Content-Type": "text/html; charset=utf-8" }
      });
    }

    // Extended Domain Locking Security Check
    const hostname = targetUrl.hostname.toLowerCase();
    const isAllowedMegaDomain = 
      hostname.endsWith(".userstorage.mega.co.nz") || hostname === "userstorage.mega.co.nz" ||
      hostname.endsWith(".userstorage.mega.nz") || hostname === "userstorage.mega.nz" ||
      hostname.endsWith(".g.api.mega.co.nz") || hostname === "g.api.mega.co.nz" ||
      hostname.endsWith(".g.api.mega.nz") || hostname === "g.api.mega.nz";

    if (!isAllowedMegaDomain) {
      return new Response("Forbidden: This proxy is strictly locked to Mega.nz domains.", { status: 403 });
    }

    // Prepare and sanitize outbound request headers
    const newHeaders = new Headers();
    const forwardedHeaders = [
      "range",
      "user-agent",
      "accept",
      "accept-encoding",
      "accept-language"
    ];

    for (const header of forwardedHeaders) {
      const value = request.headers.get(header);
      if (value) {
        newHeaders.set(header, value);
      }
    }

    try {
      const response = await fetch(targetUrl.toString(), {
        method: request.method,
        headers: newHeaders,
        redirect: "follow"
      });

      // Construct and return client response, forwarding essential headers transparently
      const outHeaders = new Headers(response.headers);
      
      // Setup CORS headers in case web portals hook into this endpoint
      outHeaders.set("Access-Control-Allow-Origin", "*");
      outHeaders.set("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
      outHeaders.set("Access-Control-Allow-Headers", "Range, User-Agent, Cache-Control");
      outHeaders.set("Access-Control-Expose-Headers", "Content-Length, Content-Range, Accept-Ranges");

      return new Response(response.body, {
        status: response.status,
        statusText: response.statusText,
        headers: outHeaders
      });
    } catch (err) {
      return new Response(`Gateway Error (Fetch Failed): ${err.message}`, { status: 502 });
    }
  }
};

/**
 * Returns a gorgeous responsive glassmorphic dashboard for visual status verification.
 */
function getDashboardHTML(origin) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MegaStreamer Bypass Gateway</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-gradient: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
      --card-bg: rgba(255, 255, 255, 0.03);
      --card-border: rgba(255, 255, 255, 0.08);
      --text-primary: #f8fafc;
      --text-secondary: #94a3b8;
      --accent-color: #6366f1;
      --accent-glow: rgba(99, 102, 241, 0.4);
      --success-green: #10b981;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--bg-gradient);
      color: var(--text-primary);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      overflow-x: hidden;
    }

    .container {
      width: 100%;
      max-width: 650px;
      position: relative;
    }

    /* Outer glowing elements for rich aesthetic */
    .glow-sphere {
      position: absolute;
      width: 300px;
      height: 300px;
      background: var(--accent-glow);
      border-radius: 50%;
      filter: blur(80px);
      z-index: 0;
      pointer-events: none;
    }
    .glow-1 { top: -100px; left: -100px; }
    .glow-2 { bottom: -100px; right: -100px; }

    .card {
      position: relative;
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-radius: 24px;
      padding: 40px;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
      z-index: 1;
      animation: fadeIn 0.8s ease-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(15px); }
      to { opacity: 1; transform: translateY(0); }
    }

    header {
      text-align: center;
      margin-bottom: 35px;
    }

    .logo-container {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: rgba(99, 102, 241, 0.1);
      border: 1px solid rgba(99, 102, 241, 0.2);
      padding: 12px 24px;
      border-radius: 50px;
      margin-bottom: 20px;
      box-shadow: 0 0 20px rgba(99, 102, 241, 0.1);
    }

    .logo-text {
      font-weight: 700;
      letter-spacing: 0.5px;
      background: linear-gradient(to right, #a5b4fc, #6366f1);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      font-size: 0.95rem;
      text-transform: uppercase;
    }

    h1 {
      font-size: 2.2rem;
      font-weight: 700;
      line-height: 1.2;
      letter-spacing: -0.5px;
      margin-bottom: 10px;
    }

    .subtitle {
      color: var(--text-secondary);
      font-size: 1.05rem;
      font-weight: 300;
    }

    .status-badge {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.08);
      border: 1px solid rgba(16, 185, 129, 0.2);
      color: var(--success-green);
      padding: 6px 14px;
      border-radius: 50px;
      font-size: 0.85rem;
      font-weight: 600;
      margin-top: 15px;
    }

    .status-dot {
      width: 8px;
      height: 8px;
      background: var(--success-green);
      border-radius: 50%;
      margin-right: 8px;
      position: relative;
    }

    .status-dot::after {
      content: '';
      position: absolute;
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background: var(--success-green);
      animation: pulse 1.8s infinite;
      top: 0;
      left: 0;
    }

    @keyframes pulse {
      0% { transform: scale(1); opacity: 1; }
      100% { transform: scale(2.5); opacity: 0; }
    }

    .divider {
      height: 1px;
      background: linear-gradient(to right, transparent, var(--card-border), transparent);
      margin: 30px 0;
    }

    .instructions h2 {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 15px;
      color: var(--text-primary);
    }

    ol {
      list-style-type: none;
      counter-reset: steps-counter;
    }

    li {
      position: relative;
      padding-left: 45px;
      margin-bottom: 20px;
      color: var(--text-secondary);
      font-size: 0.95rem;
      line-height: 1.5;
    }

    li::before {
      content: counter(steps-counter);
      counter-increment: steps-counter;
      position: absolute;
      left: 0;
      top: 2px;
      width: 28px;
      height: 28px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid var(--card-border);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--accent-color);
    }

    strong {
      color: var(--text-primary);
      font-weight: 600;
    }

    .code-box {
      background: rgba(0, 0, 0, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.05);
      padding: 12px 16px;
      border-radius: 12px;
      font-family: monospace;
      font-size: 0.9rem;
      color: #cbd5e1;
      margin-top: 10px;
      word-break: break-all;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .copy-btn {
      background: var(--accent-color);
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.75rem;
      font-weight: 600;
      transition: background 0.2s, transform 0.1s;
    }

    .copy-btn:hover {
      background: #4f46e5;
    }

    .copy-btn:active {
      transform: scale(0.95);
    }

    footer {
      text-align: center;
      margin-top: 30px;
      color: #64748b;
      font-size: 0.8rem;
    }

    footer a {
      color: var(--text-secondary);
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="glow-sphere glow-1"></div>
    <div class="glow-sphere glow-2"></div>
    
    <div class="card">
      <header>
        <div class="logo-container">
          <span class="logo-text">MegaStreamer Addon</span>
        </div>
        <h1>Bypass Gateway Active</h1>
        <p class="subtitle">Extended Cloudflare Worker</p>
        
        <div class="status-badge">
          <span class="status-dot"></span>
          Gateway Online
        </div>
      </header>

      <div class="divider"></div>

      <div class="instructions">
        <h2>Kodi Configuration Setup</h2>
        <ol>
          <li>
            Open Kodi, go to <strong>Add-ons</strong> &gt; <strong>My add-ons</strong> &gt; <strong>Video add-ons</strong> &gt; <strong>MegaStreamer</strong> and select <strong>Settings</strong>.
          </li>
          <li>
            Navigate to the <strong>Enhancements</strong> tab.
          </li>
          <li>
            Enable the <strong>Secure Cloudflare Worker</strong> setting.
          </li>
          <li>
            Enter the following URL into the <strong>Worker URL</strong> field:
            <div class="code-box">
              <span id="worker-url">${origin}</span>
              <button class="copy-btn" onclick="copyUrl()">Copy URL</button>
            </div>
          </li>
        </ol>
      </div>
    </div>
    
    <footer>
      Powered by <a href="https://github.com/movieshark" target="_blank">MegaStreamer v0.4</a> &bull; Extended Whitelist Enabled
    </footer>
  </div>

  <script>
    function copyUrl() {
      const urlText = document.getElementById('worker-url').textContent;
      navigator.clipboard.writeText(urlText).then(() => {
        const btn = document.querySelector('.copy-btn');
        btn.textContent = 'Copied!';
        btn.style.background = '#10b981';
        setTimeout(() => {
          btn.textContent = 'Copy URL';
          btn.style.background = '#6366f1';
        }, 2000);
      });
    }
  </script>
</body>
</html>`;
}
