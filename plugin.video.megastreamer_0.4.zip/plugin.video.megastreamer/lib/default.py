import json
import os
import re
import struct
import sys
import hashlib
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from megastreamer import get_file_info, init_and_play, init_and_play_private, init_and_play_gdrive
from megastreamer.mega import MegaClient, MegaSessionExpiredException
from megastreamer.crypto_utils import encrypt_password, decrypt_password
from megastreamer.gdrive import GoogleDriveClient
import socket
import threading
import urllib.parse
import time

class OAuthRedirectListener(threading.Thread):
    def __init__(self, port=53682):
        super(OAuthRedirectListener, self).__init__()
        self.port = port
        self.code = None
        self.running = True
        self.sock = None

    def run(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.sock.bind(('127.0.0.1', self.port))
            self.sock.listen(1)
            self.sock.settimeout(2.0)
            
            while self.running:
                try:
                    conn, addr = self.sock.accept()
                    request_data = conn.recv(2048).decode('utf-8', errors='ignore')
                    
                    lines = request_data.split('\n')
                    if len(lines) > 0:
                        parts = lines[0].split(' ')
                        if len(parts) > 1:
                            path = parts[1]
                            parsed = urllib.parse.urlparse(path)
                            params = urllib.parse.parse_qs(parsed.query)
                            self.code = params.get('code', [None])[0]
                    
                    response_body = """
                    <html>
                    <head>
                        <title>MegaStreamer Autorisierung</title>
                        <meta charset="utf-8">
                    </body style="font-family: Arial, sans-serif; text-align: center; padding-top: 50px; background-color: #121212; color: #ffffff;">
                        <h2 style="color: #4CAF50;">✔ Erfolgreich autorisiert!</h2>
                        <p>MegaStreamer hat die Anmeldedaten empfangen.</p>
                        <p>Sie koennen dieses Browserfenster jetzt schliessen und zu Kodi zurückkehren.</p>
                    </body>
                    </html>
                    """
                    conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n" + response_body.encode('utf-8'))
                    conn.close()
                    self.running = False
                except socket.timeout:
                    continue
                except Exception:
                    break
        except Exception:
            pass
        finally:
            try:
                self.sock.close()
            except Exception:
                pass

    def stop(self):
        self.running = False


def run_oauth_flow(client, addon):
    listener = OAuthRedirectListener()
    listener.daemon = True
    listener.start()

    auth_url = client.get_auth_url()
    
    try:
        import webbrowser
        webbrowser.open(auth_url)
    except Exception:
        pass

    dialog = xbmcgui.DialogProgress()
    dialog.create(
        "Google Drive Verbindung",
        "Ein Browserfenster wurde geoeffnet (falls unterstuetzt).\n"
        "Falls nicht, rufen Sie bitte folgende URL im Browser auf:\n"
        f"[COLOR yellow]{auth_url}[/COLOR]\n\n"
        "Warte auf Freigabe..."
    )

    start_time = time.time()
    expires_in = 300
    success = False
    code = None

    try:
        import time as pytime
        while pytime.time() - start_time < expires_in:
            if dialog.iscanceled():
                break

            if listener.code:
                code = listener.code
                success = True
                break

            elapsed = pytime.time() - start_time
            pct = int((elapsed / expires_in) * 100)
            dialog.update(
                pct,
                "Ein Browserfenster wurde geoeffnet (falls unterstuetzt).\n"
                "Falls nicht, rufen Sie bitte folgende URL im Browser auf:\n"
                f"[COLOR yellow]{auth_url}[/COLOR]\n\n"
                f"Warte auf Freigabe... ({int(expires_in - elapsed)}s verbleibend)"
            )
            pytime.sleep(1)
    finally:
        dialog.close()
        listener.stop()

    if not success:
        manual_code = xbmcgui.Dialog().input(
            "Google Drive Autorisierung",
            "Geben Sie den 'code' aus der Adresszeile ein (oder leer zum Abbrechen):",
            type=xbmcgui.INPUT_ALPHANUM
        )
        if manual_code:
            code = manual_code.strip()
            success = True

    if success and code:
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        try:
            client.exchange_code(code)
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            addon.setSetting("gdrive_enabled", "true")
            xbmcgui.Dialog().ok("Erfolgreich", addon.getLocalizedString(30066) or "Google Drive erfolgreich verbunden.")
            return True
        except Exception as ex:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            show_error("Verbindungsfehler", str(ex))
            return False
            
    xbmcgui.Dialog().notification("Google Drive", "Verbindung abgebrochen.")
    return False


def show_error(title, message):
    xbmcgui.Dialog().ok(title, message)


def get_session_file_path(addon, email):
    email_hash = hashlib.sha256(email.lower().encode('utf-8')).hexdigest()[:12]
    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not xbmcvfs.exists(profile_path):
        xbmcvfs.mkdir(profile_path)
    return os.path.join(profile_path, f'session_{email_hash}.json')


def load_cached_session(addon, email):
    session_file = get_session_file_path(addon, email)
    if os.path.exists(session_file):
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if data.get("email") == email.lower() and data.get("sid") and data.get("master_key"):
                return data
        except Exception as e:
            xbmc.log(f"[megastreamer] Error loading session cache for {email}: {e}", xbmc.LOGERROR)
    return None


def save_cached_session(addon, email, client):
    session_file = get_session_file_path(addon, email)
    try:
        session_data = client.dump_session()
        session_data["email"] = email.lower()
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session_data, f)
    except Exception as e:
        xbmc.log(f"[megastreamer] Error saving session cache for {email}: {e}", xbmc.LOGERROR)


def clear_cached_session(addon, email):
    session_file = get_session_file_path(addon, email)
    if os.path.exists(session_file):
        try:
            os.remove(session_file)
        except Exception as e:
            xbmc.log(f"[megastreamer] Error clearing session cache: {e}", xbmc.LOGERROR)


def get_account_credentials(addon, slot):
    slot_str = "" if slot == "1" else f"_{slot}"
    email = addon.getSetting(f"megaemail{slot_str}")
    password_raw = addon.getSetting(f"megapassword{slot_str}")
    
    if not email or not password_raw:
        return None, None
        
    if password_raw.startswith("enc_"):
        password = decrypt_password(password_raw[4:])
    else:
        password = password_raw
        addon.setSetting(f"megapassword{slot_str}", "enc_" + encrypt_password(password))
        
    return email, password


def get_gdrive_credentials(addon):
    client_id = addon.getSetting("gdrive_client_id").strip()
    secret_raw = addon.getSetting("gdrive_client_secret").strip()
    
    if not client_id or not secret_raw:
        raise ValueError(
            "Google Drive Client-ID und Client-Secret sind zwingend erforderlich!\n"
            "Bitte erstellen Sie eine Desktop-Anwendung in der Google Cloud Console und tragen Sie beide Werte in den Addon-Einstellungen ein."
        )
        
    if secret_raw.startswith("enc_"):
        client_secret = decrypt_password(secret_raw[4:])
    else:
        client_secret = secret_raw
        addon.setSetting("gdrive_client_secret", "enc_" + encrypt_password(client_secret))
        
    return client_id, client_secret


def get_mega_client_for_slot(addon, slot):
    email, password = get_account_credentials(addon, slot)
    if not email or not password:
        raise ValueError(f"Keine Zugangsdaten für Slot {slot} hinterlegt. Bitte in den Einstellungen eintragen.")
        
    client = MegaClient(email, password)
    cached = load_cached_session(addon, email)
    if cached:
        xbmc.log(f"[megastreamer] Using cached session ID for Slot {slot}.", xbmc.LOGINFO)
        client.load_session(cached["sid"], cached["master_key"], cached.get("root_id"))
    else:
        xbmc.log(f"[megastreamer] No cached session for Slot {slot}, performing fresh login.", xbmc.LOGINFO)
        if not client.login():
            raise ValueError(f"Login für Slot {slot} fehlgeschlagen. Bitte prüfe E-Mail und Passwort.")
        save_cached_session(addon, email, client)
    return client


def parse_mega_url(url):
    # Public file
    m = re.match(r"^https?://mega(?:\.co)?\.nz/file/([A-Za-z0-9_-]+)#([A-Za-z0-9_-]+)$", url)
    if m:
        return "file", m.group(1), m.group(2)
    m = re.match(r"^https?://mega(?:\.co)?\.nz/#!([A-Za-z0-9_-]+)!([A-Za-z0-9_-]+)$", url)
    if m:
        return "file", m.group(1), m.group(2)

    # Public folder
    m = re.match(r"^https?://mega(?:\.co)?\.nz/folder/([A-Za-z0-9_-]+)#([A-Za-z0-9_-]+)$", url)
    if m:
        return "folder", m.group(1), m.group(2)
    m = re.match(r"^https?://mega(?:\.co)?\.nz/#F!([A-Za-z0-9_-]+)!([A-Za-z0-9_-]+)$", url)
    if m:
        return "folder", m.group(1), m.group(2)

    return None, None, None


def get_imported_file_path(addon):
    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not xbmcvfs.exists(profile_path):
        xbmcvfs.mkdir(profile_path)
    return os.path.join(profile_path, 'imported.json')


def load_imported_links(addon):
    path = get_imported_file_path(addon)
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return []


def save_imported_links(addon, links):
    path = get_imported_file_path(addon)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(links, f, indent=4, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"[megastreamer] Error saving imported links: {e}", xbmc.LOGERROR)



if __name__ == "__main__":
    addon = xbmcaddon.Addon(id="plugin.video.megastreamer")
    
    # Auto-encrypt passwords across all 5 slots upon any addon interaction
    for slot in ["1", "2", "3", "4", "5"]:
        try:
            get_account_credentials(addon, slot)
        except Exception:
            pass
    try:
        get_gdrive_credentials(addon)
    except Exception:
        pass

    plugin_url = sys.argv[0] if len(sys.argv) > 0 else ""
    
    plugin_handle = -1
    if len(sys.argv) > 1 and sys.argv[1]:
        try:
            plugin_handle = int(sys.argv[1])
        except ValueError:
            pass
            
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        params = dict(parse_qsl(sys.argv[2].replace("?", "")))
        
    action = params.get("action")

    if action == "play":
        # Stream a single public direct link
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        mega_url = params.get("url")
        user_agent = params.get("user_agent", "Mozilla/5.0")
        proxy = params.get("proxy")
        
        # Use Primary Streaming Account session ID if available to route quota
        sid = None
        try:
            slot = addon.getSetting("streaming_account")
            email, _ = get_account_credentials(addon, slot)
            if email:
                cached = load_cached_session(addon, email)
                if cached:
                    sid = cached.get("sid")
        except Exception:
            pass

        info = get_file_info(mega_url, {"User-Agent": user_agent}, sid=sid, proxy=proxy)
        listitem = xbmcgui.ListItem(info["data"]["at"]["n"])
        init_and_play(mega_url, user_agent, listitem=listitem, plugin_handle=plugin_handle, sid=sid, proxy=proxy)

    elif action == "play_private":
        # Play private file using active account session
        file_id = params.get("file_id")
        slot = addon.getSetting("active_account")
        email, password = get_account_credentials(addon, slot)

        if not email or not password:
            show_error("megastreamer", addon.getLocalizedString(30171) or "Bitte trage die MEGA-Zugangsdaten in den Addon-Einstellungen ein.")
            addon.openSettings()
            sys.exit(0)

        xbmc.executebuiltin("ActivateWindow(busydialog)")
        try:
            try:
                client = get_mega_client_for_slot(addon, slot)
                files = client.get_files()
                if file_id not in files:
                    raise ValueError("Datei nicht gefunden.")
                file_node = files[file_id]
                direct_link_data = client.get_download_link(file_id)
            except MegaSessionExpiredException:
                clear_cached_session(addon, email)
                client = get_mega_client_for_slot(addon, slot)
                files = client.get_files()
                if file_id not in files:
                    raise ValueError("Datei nicht gefunden.")
                file_node = files[file_id]
                direct_link_data = client.get_download_link(file_id)

            key_hex = struct.pack('!4I', *file_node['k']).hex()
            iv_hex = struct.pack('!4I', *file_node['iv']).hex()

            xbmc.executebuiltin("Dialog.Close(busydialog)")
            listitem = xbmcgui.ListItem(file_node['a']['n'])
            init_and_play_private(
                direct_url=direct_link_data['g'],
                key_hex=key_hex,
                iv_hex=iv_hex,
                size=direct_link_data['s'],
                name=file_node['a']['n'],
                listitem=listitem,
                plugin_handle=plugin_handle
            )
        except Exception as e:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            show_error("megastreamer Error", str(e))

    elif action == "list_private":
        # Private cloud browsing
        slot = addon.getSetting("active_account")
        email, password = get_account_credentials(addon, slot)

        if not email or not password:
            show_error("megastreamer", "Bitte trage die MEGA-Zugangsdaten in den Addon-Einstellungen ein.")
            addon.openSettings()
            xbmcplugin.endOfDirectory(plugin_handle, False)
        else:
            xbmc.executebuiltin("ActivateWindow(busydialog)")
            try:
                try:
                    client = get_mega_client_for_slot(addon, slot)
                    files = client.get_files()
                except MegaSessionExpiredException:
                    clear_cached_session(addon, email)
                    client = get_mega_client_for_slot(addon, slot)
                    files = client.get_files()

                xbmc.executebuiltin("Dialog.Close(busydialog)")
                folder_id = params.get("folder_id")
                if not folder_id:
                    folder_id = client.root_id

                # Categorize and sort folders and files ascending
                subfolders = []
                playable_files = []
                for handle, node in files.items():
                    if node.get('p') == folder_id:
                        if node['t'] == 1:
                            subfolders.append(node)
                        elif node['t'] == 0:
                            name_lower = node['a']['n'].lower()
                            extensions = ['.mp4', '.mkv', '.avi', '.flv', '.mov', '.wmv', '.mpg', '.mpeg', '.m4v',
                                          '.mp3', '.wav', '.flac', '.ogg', '.m4a', '.aac']
                            if any(name_lower.endswith(ext) for ext in extensions):
                                playable_files.append(node)

                # Sort alphabetically ascending
                subfolders.sort(key=lambda x: x['a']['n'].lower())
                playable_files.sort(key=lambda x: x['a']['n'].lower())

                # Add folders first
                for node in subfolders:
                    handle = node['h']
                    url = f"{plugin_url}?action=list_private&folder_id={handle}"
                    listitem = xbmcgui.ListItem(label=node['a']['n'])
                    listitem.setArt({'icon': 'DefaultFolder.png'})
                    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, True)

                # Add playable files
                for node in playable_files:
                    handle = node['h']
                    url = f"{plugin_url}?action=play_private&file_id={handle}"
                    listitem = xbmcgui.ListItem(label=node['a']['n'])
                    listitem.setProperty("IsPlayable", "true")
                    listitem.setArt({'icon': 'DefaultVideo.png'})
                    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, False)

                xbmcplugin.setContent(plugin_handle, 'videos')
                xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_LABEL)
                xbmcplugin.endOfDirectory(plugin_handle, True)
            except Exception as e:
                xbmc.executebuiltin("Dialog.Close(busydialog)")
                show_error("megastreamer Error", str(e))
                xbmcplugin.endOfDirectory(plugin_handle, False)

    elif action == "import_file":
        # Import MEGA Links from a text file (.txt or .links)
        file_path = xbmcgui.Dialog().browse(1, addon.getLocalizedString(30043) or "Links-Datei auswählen", "files", ".txt|.links")
        if file_path:
            xbmc.executebuiltin("ActivateWindow(busydialog)")
            try:
                f = xbmcvfs.File(file_path, 'r')
                content = f.read()
                f.close()
                
                if isinstance(content, bytes):
                    content = content.decode('utf-8', errors='ignore')
                    
                lines = [line.strip() for line in content.splitlines() if line.strip()]
                valid_urls = []
                for line in lines:
                    parts = [p.strip().strip('"').strip("'") for p in line.split(';')]
                    if not parts or not parts[0]:
                        continue
                    url = parts[0]
                    link_type, handle, key = parse_mega_url(url)
                    if link_type:
                        custom_name = parts[1] if len(parts) > 1 and parts[1] else None
                        category = parts[2] if len(parts) > 2 and parts[2] else None
                        year = parts[3] if len(parts) > 3 and parts[3] else None
                        valid_urls.append((url, link_type, handle, key, custom_name, category, year))
                        
                if not valid_urls:
                    xbmc.executebuiltin("Dialog.Close(busydialog)")
                    show_error("megastreamer", "Keine gültigen MEGA-Links in der Datei gefunden.")
                else:
                    slot = addon.getSetting("streaming_account")
                    client = get_mega_client_for_slot(addon, slot)
                    links = load_imported_links(addon)
                    imported_count = 0
                    
                    for url, link_type, handle, key, custom_name, category, year in valid_urls:
                        exists = False
                        for link in links:
                            if link.get("handle") == handle:
                                exists = True
                                break
                        if exists:
                            continue
                            
                        name = custom_name if custom_name else f"Importiert ({handle})"
                        if not custom_name:
                            try:
                                if link_type == "file":
                                    info = get_file_info(url, {"User-Agent": "Mozilla/5.0"}, sid=client.sid)
                                    name = info["data"]["at"]["n"]
                                elif link_type == "folder":
                                    files = client.get_public_folder_files(handle, key)
                                    root_node = None
                                    for node in files.values():
                                        if node.get('p') not in files:
                                            root_node = node
                                            break
                                    if root_node and root_node.get('a'):
                                        name = root_node['a']['n']
                            except Exception:
                                pass
                                
                        links.append({
                            "url": url,
                            "type": link_type,
                            "handle": handle,
                            "key": key,
                            "name": name,
                            "category": category,
                            "year": year,
                            "hash": hashlib.md5(url.encode('utf-8')).hexdigest()
                        })
                        imported_count += 1
                        
                    save_imported_links(addon, links)
                    xbmc.executebuiltin("Dialog.Close(busydialog)")
                    
                    msg = addon.getLocalizedString(30045) or "{0} Links erfolgreich importiert."
                    xbmcgui.Dialog().notification("megastreamer", msg.format(imported_count))
                    xbmc.executebuiltin("Container.Refresh")
            except Exception as e:
                xbmc.executebuiltin("Dialog.Close(busydialog)")
                show_error("megastreamer Error", str(e))

    elif action == "list_imported":
        # List all permanently imported MEGA files and folders
        links = load_imported_links(addon)
        links.sort(key=lambda x: x.get("name", "").lower())
        for link in links:
            name = link["name"]
            handle = link["handle"]
            key = link["key"]
            l_hash = link["hash"]
            
            if link["type"] == "folder":
                url = f"{plugin_url}?action=browse_public_folder&folder_id={handle}&folder_key={key}"
                listitem = xbmcgui.ListItem(label=name)
                listitem.setArt({'icon': 'DefaultFolder.png'})
                is_folder = True
            else:
                url = f"{plugin_url}?action=play_public_file&file_id={handle}&folder_key={key}"
                listitem = xbmcgui.ListItem(label=name)
                listitem.setProperty("IsPlayable", "true")
                listitem.setArt({'icon': 'DefaultVideo.png'})
                is_folder = False
                
            # Set metadata labels if present
            info_labels = {}
            if link.get("category"):
                info_labels["genre"] = link["category"]
            if link.get("year"):
                try:
                    info_labels["year"] = int(link["year"])
                except ValueError:
                    pass
            if info_labels:
                listitem.setInfo('video', info_labels)
                
            # Context menu to remove or rename import
            rem_label = addon.getLocalizedString(30025) or "Import entfernen"
            ren_label = addon.getLocalizedString(30046) or "Import umbenennen"
            listitem.addContextMenuItems([
                (rem_label, f"RunPlugin({plugin_url}?action=delete_import&hash={l_hash})"),
                (ren_label, f"RunPlugin({plugin_url}?action=rename_import&hash={l_hash})")
            ])
            xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, is_folder)
            
        xbmcplugin.endOfDirectory(plugin_handle, True)

    elif action == "delete_import":
        # Delete an imported link from persistent imported.json
        l_hash = params.get("hash")
        links = load_imported_links(addon)
        links = [l for l in links if l.get("hash") != l_hash]
        save_imported_links(addon, links)
        xbmc.executebuiltin("Container.Refresh")

    elif action == "rename_import":
        # Rename an imported link in persistent imported.json
        l_hash = params.get("hash")
        links = load_imported_links(addon)
        target_link = next((l for l in links if l.get("hash") == l_hash), None)
        if target_link:
            current_name = target_link.get("name", "")
            title = addon.getLocalizedString(30047) or "Neuen Namen eingeben:"
            new_name = xbmcgui.Dialog().input(title, defaultt=current_name)
            if new_name and new_name != current_name:
                target_link["name"] = new_name
                save_imported_links(addon, links)
                xbmc.executebuiltin("Container.Refresh")

    elif action == "browse_public_folder":
        # Browse public shared folder
        folder_id = params.get("folder_id")
        folder_key = params.get("folder_key")
        subfolder_id = params.get("subfolder_id")
        
        slot = addon.getSetting("streaming_account")
        
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        try:
            client = get_mega_client_for_slot(addon, slot)
            files = client.get_public_folder_files(folder_id, folder_key)
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            
            # Find the root node of this share (whose parent is not in files)
            root_node = None
            for node in files.values():
                if node.get('p') not in files:
                    root_node = node
                    break
            current_parent = subfolder_id if subfolder_id else (root_node['h'] if root_node else folder_id)
            folder_name = root_node['a']['n'] if root_node else "Shared Folder"
            
            # Special command: Play all as playlist
            play_all_label = f"[ {addon.getLocalizedString(30024) or 'Alle abspielen (Playlist)'} ]"
            sub_param = f"&subfolder_id={subfolder_id}" if subfolder_id else ""
            url_play_all = f"{plugin_url}?action=play_all_public_folder&folder_id={folder_id}&folder_key={folder_key}{sub_param}"
            listitem = xbmcgui.ListItem(label=play_all_label)
            listitem.setArt({'icon': 'DefaultMusicPlaylists.png'})
            xbmcplugin.addDirectoryItem(plugin_handle, url_play_all, listitem, False)

            # Categorize and sort folders and files ascending
            subfolders = []
            playable_files = []
            for handle, node in files.items():
                if node.get('p') == current_parent:
                    if node['t'] == 1:
                        subfolders.append(node)
                    elif node['t'] == 0:
                        name_lower = node['a']['n'].lower()
                        extensions = ['.mp4', '.mkv', '.avi', '.flv', '.mov', '.wmv', '.mpg', '.mpeg', '.m4v',
                                      '.mp3', '.wav', '.flac', '.ogg', '.m4a', '.aac']
                        if any(name_lower.endswith(ext) for ext in extensions):
                            playable_files.append(node)

            # Sort alphabetically ascending
            subfolders.sort(key=lambda x: x['a']['n'].lower())
            playable_files.sort(key=lambda x: x['a']['n'].lower())

            # Add folders first
            for node in subfolders:
                handle = node['h']
                url = f"{plugin_url}?action=browse_public_folder&folder_id={folder_id}&folder_key={folder_key}&subfolder_id={handle}"
                listitem = xbmcgui.ListItem(label=node['a']['n'])
                listitem.setArt({'icon': 'DefaultFolder.png'})
                xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, True)

            # Add playable files
            for node in playable_files:
                handle = node['h']
                url = f"{plugin_url}?action=play_public_file&folder_id={folder_id}&file_id={handle}&folder_key={folder_key}"
                listitem = xbmcgui.ListItem(label=node['a']['n'])
                listitem.setProperty("IsPlayable", "true")
                listitem.setArt({'icon': 'DefaultVideo.png'})
                xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, False)

            xbmcplugin.setContent(plugin_handle, 'videos')
            xbmcplugin.endOfDirectory(plugin_handle, True)
        except Exception as e:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            show_error("megastreamer Error", str(e))
            xbmcplugin.endOfDirectory(plugin_handle, False)

    elif action == "play_public_file":
        # Stream file from a public folder or link
        folder_id = params.get("folder_id")
        file_id = params.get("file_id")
        folder_key = params.get("folder_key")
        
        slot = addon.getSetting("streaming_account")
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        try:
            client = get_mega_client_for_slot(addon, slot)
            
            if not folder_id:
                # Standalone public file link: reconstruct original MEGA url and route via session
                mega_url = f"https://mega.nz/file/{file_id}#{folder_key}"
                info = get_file_info(mega_url, {"User-Agent": "Mozilla/5.0"}, sid=client.sid)
                
                xbmc.executebuiltin("Dialog.Close(busydialog)")
                listitem = xbmcgui.ListItem(info["data"]["at"]["n"])
                init_and_play(mega_url, "Mozilla/5.0", listitem=listitem, plugin_handle=plugin_handle, sid=client.sid)
            else:
                # File inside a public shared folder
                files = client.get_public_folder_files(folder_id, folder_key)
                if file_id not in files:
                    raise ValueError("Datei nicht im freigegebenen Ordner gefunden.")
                file_node = files[file_id]
                direct_link_data = client.get_download_link(file_id, folder_handle=folder_id)
                
                key_hex = struct.pack('!4I', *file_node['k']).hex()
                iv_hex = struct.pack('!4I', *file_node['iv']).hex()

                xbmc.executebuiltin("Dialog.Close(busydialog)")
                listitem = xbmcgui.ListItem(file_node['a']['n'])
                init_and_play_private(
                    direct_url=direct_link_data['g'],
                    key_hex=key_hex,
                    iv_hex=iv_hex,
                    size=direct_link_data['s'],
                    name=file_node['a']['n'],
                    listitem=listitem,
                    plugin_handle=plugin_handle
                )
        except Exception as e:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            show_error("megastreamer Error", str(e))

    elif action == "play_all_public_folder":
        # Clear playlist, queue all files in the current folder path, start playing
        folder_id = params.get("folder_id")
        folder_key = params.get("folder_key")
        subfolder_id = params.get("subfolder_id")
        
        slot = addon.getSetting("streaming_account")
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        try:
            client = get_mega_client_for_slot(addon, slot)
            files = client.get_public_folder_files(folder_id, folder_key)
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            
            # Find the root node of this share (whose parent is not in files)
            root_node = None
            for node in files.values():
                if node.get('p') not in files:
                    root_node = node
                    break
            current_parent = subfolder_id if subfolder_id else (root_node['h'] if root_node else folder_id)
            folder_name = root_node['a']['n'] if root_node else "Shared Folder"
            
            # Find and sort all files in this level
            playable_nodes = []
            for handle, node in files.items():
                if node.get('p') == current_parent and node['t'] == 0:
                    name = node['a']['n'].lower()
                    extensions = ['.mp4', '.mkv', '.avi', '.flv', '.mov', '.wmv', '.mpg', '.mpeg', '.m4v',
                                  '.mp3', '.wav', '.flac', '.ogg', '.m4a', '.aac']
                    if any(name.endswith(ext) for ext in extensions):
                        playable_nodes.append(node)
            
            # Sort by name
            playable_nodes.sort(key=lambda x: x['a']['n'].lower())
            
            if not playable_nodes:
                show_error("megastreamer", "Keine abspielbaren Mediendateien in diesem Ordner gefunden.")
                sys.exit(0)
                
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            
            for node in playable_nodes:
                play_url = f"{plugin_url}?action=play_public_file&folder_id={folder_id}&file_id={node['h']}&folder_key={folder_key}"
                listitem = xbmcgui.ListItem(node['a']['n'])
                listitem.setProperty("IsPlayable", "true")
                listitem.setProperty("mega_folder", folder_name)
                listitem.setProperty("mega_name", node['a']['n'])
                listitem.setArt({'icon': 'DefaultVideo.png'})
                playlist.add(play_url, listitem)
                
            xbmc.Player().play(playlist)
        except Exception as e:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            show_error("megastreamer Error", str(e))

    elif action == "connect_gdrive":
        xbmc.executebuiltin("Dialog.Close(addonsettings)")
        client_id, client_secret = get_gdrive_credentials(addon)
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        session_path = os.path.join(profile_path, 'gdrive_session.json')

        client = GoogleDriveClient(client_id, client_secret, session_path)
        if run_oauth_flow(client, addon):
            xbmc.executebuiltin("Container.Refresh")

    elif action == "disconnect_gdrive":
        xbmc.executebuiltin("Dialog.Close(addonsettings)")
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        session_path = os.path.join(profile_path, 'gdrive_session.json')
        client = GoogleDriveClient(session_path=session_path)
        client.clear_session()
        addon.setSetting("gdrive_enabled", "false")
        xbmcgui.Dialog().ok("Google Drive", addon.getLocalizedString(30067) or "Google Drive-Konto getrennt.")
        xbmc.executebuiltin("Container.Refresh")

    elif action == "list_gdrive":
        folder_id = params.get("folder_id", "root")

        client_id, client_secret = get_gdrive_credentials(addon)
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        session_path = os.path.join(profile_path, 'gdrive_session.json')

        client = GoogleDriveClient(client_id, client_secret, session_path)

        if not client.is_authenticated():
            confirm = xbmcgui.Dialog().yesno(
                "Google Drive",
                "Ihr Google-Konto ist noch nicht verbunden.\n"
                "Möchten Sie die Verbindung jetzt herstellen?"
            )
            if confirm:
                run_oauth_flow(client, addon)
            xbmcplugin.endOfDirectory(plugin_handle, False)
            sys.exit(0)

        xbmc.executebuiltin("ActivateWindow(busydialog)")
        try:
            folders, playable_files = client.list_files(folder_id)
            xbmc.executebuiltin("Dialog.Close(busydialog)")

            for folder in folders:
                url = f"{plugin_url}?action=list_gdrive&folder_id={folder['id']}"
                listitem = xbmcgui.ListItem(label=folder['name'])
                listitem.setArt({'icon': 'DefaultFolder.png'})
                xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, True)

            for file in playable_files:
                url = f"{plugin_url}?action=play_gdrive&file_id={file['id']}"
                listitem = xbmcgui.ListItem(label=file['name'])
                listitem.setProperty("IsPlayable", "true")
                listitem.setArt({'icon': 'DefaultVideo.png'})

                if file.get("size"):
                    try:
                        size_bytes = int(file["size"])
                        listitem.setInfo('video', {'size': size_bytes})
                    except ValueError:
                        pass

                xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, False)

            xbmcplugin.setContent(plugin_handle, 'videos')
            xbmcplugin.endOfDirectory(plugin_handle, True)
        except Exception as e:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            show_error("Google Drive Fehler", str(e))
            xbmcplugin.endOfDirectory(plugin_handle, False)

    elif action == "play_gdrive":
        file_id = params.get("file_id")
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        try:
            client_id, client_secret = get_gdrive_credentials(addon)
            profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
            session_path = os.path.join(profile_path, 'gdrive_session.json')

            client = GoogleDriveClient(client_id, client_secret, session_path)
            metadata = client.get_file_metadata(file_id)
            name = metadata.get("name", "video.mp4")

            xbmc.executebuiltin("Dialog.Close(busydialog)")
            listitem = xbmcgui.ListItem(name)
            init_and_play_gdrive(
                file_id=file_id,
                name=name,
                listitem=listitem,
                plugin_handle=plugin_handle
            )
        except Exception as e:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            show_error("Google Drive Fehler", str(e))

    else:
        # Default main root menu
        addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
        media_path = os.path.join(addon_path, 'resources', 'media')
        
        # 1. Private Cloud
        url_priv = f"{plugin_url}?action=list_private"
        lbl_priv = addon.getLocalizedString(30040) or "Mein MEGA Cloud-Speicher"
        listitem = xbmcgui.ListItem(label=lbl_priv)
        listitem.setArt({'icon': os.path.join(media_path, 'my_mega_cloud.png')})
        xbmcplugin.addDirectoryItem(plugin_handle, url_priv, listitem, True)

        # 1.5 Google Drive (if enabled)
        if addon.getSetting("gdrive_enabled") == "true":
            url_gdrive = f"{plugin_url}?action=list_gdrive"
            lbl_gdrive = addon.getLocalizedString(30068) or "Mein Google Drive"
            listitem = xbmcgui.ListItem(label=lbl_gdrive)
            listitem.setArt({'icon': os.path.join(media_path, 'my_gdrive_cloud.png')})
            xbmcplugin.addDirectoryItem(plugin_handle, url_gdrive, listitem, True)
        
        # 2. Import Links from Text File
        url_file = f"{plugin_url}?action=import_file"
        lbl_file = addon.getLocalizedString(30042) or "MEGA Links aus Textdatei importieren"
        listitem = xbmcgui.ListItem(label=lbl_file)
        listitem.setArt({'icon': os.path.join(media_path, 'import_mega_links.png')})
        xbmcplugin.addDirectoryItem(plugin_handle, url_file, listitem, False)
        
        # 3. List Imported Items
        url_list_imp = f"{plugin_url}?action=list_imported"
        lbl_list_imp = addon.getLocalizedString(30023) or "Importierte MEGA Links & Ordner"
        listitem = xbmcgui.ListItem(label=lbl_list_imp)
        listitem.setArt({'icon': os.path.join(media_path, 'imported_mega_links.png')})
        xbmcplugin.addDirectoryItem(plugin_handle, url_list_imp, listitem, True)
        
        xbmcplugin.endOfDirectory(plugin_handle, True)
