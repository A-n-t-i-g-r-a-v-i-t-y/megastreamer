import os
import json
import time
import requests

DEFAULT_CLIENT_ID = "202264815644.apps.googleusercontent.com"
DEFAULT_CLIENT_SECRET = "x4o5ZgTL2PBc4_7cK6Ls_Om4"

class GoogleDriveClient:
    def __init__(self, client_id=None, client_secret=None, session_path=None):
        self.client_id = client_id if client_id else DEFAULT_CLIENT_ID
        self.client_secret = client_secret if client_secret else DEFAULT_CLIENT_SECRET
        self.session_path = session_path
        self.access_token = None
        self.refresh_token = None
        self.expires_at = 0
        self.email = None
        self.load_session()

    def load_session(self):
        if self.session_path and os.path.exists(self.session_path):
            try:
                with open(self.session_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self.access_token = data.get("access_token")
                self.refresh_token = data.get("refresh_token")
                self.expires_at = data.get("expires_at", 0)
                self.email = data.get("email")
            except Exception:
                pass

    def save_session(self):
        if self.session_path:
            try:
                data = {
                    "access_token": self.access_token,
                    "refresh_token": self.refresh_token,
                    "expires_at": self.expires_at,
                    "email": self.email
                }
                with open(self.session_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=4)
            except Exception:
                pass

    def clear_session(self):
        self.access_token = None
        self.refresh_token = None
        self.expires_at = 0
        self.email = None
        if self.session_path and os.path.exists(self.session_path):
            try:
                os.remove(self.session_path)
            except Exception:
                pass

    def is_authenticated(self):
        return bool(self.refresh_token)

    def get_auth_url(self):
        """Generate standard browser authorization URL."""
        import urllib.parse
        params = {
            "client_id": self.client_id,
            "redirect_uri": "http://127.0.0.1:53682/",
            "response_type": "code",
            "scope": "https://www.googleapis.com/auth/drive.readonly",
            "access_type": "offline",
            "prompt": "consent"
        }
        return "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode(params)

    def exchange_code(self, code):
        """Exchange authorization code for access and refresh tokens."""
        url = "https://oauth2.googleapis.com/token"
        payload = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "code": code,
            "redirect_uri": "http://127.0.0.1:53682/",
            "grant_type": "authorization_code"
        }
        res = requests.post(url, data=payload, timeout=10)
        
        if res.status_code != 200:
            try:
                err_data = res.json()
                err_msg = err_data.get("error_description") or err_data.get("error") or res.text
                raise Exception(f"Google Token Exchange Error ({res.status_code}): {err_msg}")
            except Exception as e:
                if "Google Token Exchange Error" in str(e):
                    raise
                res.raise_for_status()

        data = res.json()
        self.access_token = data.get("access_token")
        self.refresh_token = data.get("refresh_token")
        self.expires_at = int(time.time()) + int(data.get("expires_in", 3600))
        
        self.fetch_user_email()
        self.save_session()
        return self.access_token

    def request_device_code(self):
        """Step 1 of OAuth Device Flow: Request device authorization code."""
        url = "https://oauth2.googleapis.com/device/code"
        payload = {
            "client_id": self.client_id,
            "scope": "https://www.googleapis.com/auth/drive.readonly"
        }
        if self.client_secret:
            payload["client_secret"] = self.client_secret
            
        res = requests.post(url, data=payload, timeout=10)
        
        if res.status_code != 200:
            try:
                err_data = res.json()
                err_msg = err_data.get("error_description") or err_data.get("error") or res.text
                raise Exception(f"Google API Error ({res.status_code}): {err_msg}")
            except Exception as e:
                if "Google API Error" in str(e):
                    raise
                res.raise_for_status()
                
        data = res.json()
        
        # Returns: device_code, user_code, verification_url, expires_in, interval
        return data

    def poll_token(self, device_code):
        """Step 2 of OAuth Device Flow: Poll token endpoint for status."""
        url = "https://oauth2.googleapis.com/token"
        payload = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "device_code": device_code,
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code"
        }
        res = requests.post(url, data=payload, timeout=10)
        if res.status_code == 400:
            err = res.json().get("error")
            if err in ("authorization_pending", "slow_down"):
                return None
            raise ValueError(f"Authorization failed: {err}")
        
        res.raise_for_status()
        data = res.json()
        
        self.access_token = data.get("access_token")
        self.refresh_token = data.get("refresh_token")
        self.expires_at = int(time.time()) + int(data.get("expires_in", 3600))
        
        # Try fetching email to complete profile info
        self.fetch_user_email()
        self.save_session()
        return self.access_token

    def fetch_user_email(self):
        """Fetch user email to display in the settings."""
        if not self.access_token:
            return
        try:
            url = "https://www.googleapis.com/drive/v3/about"
            headers = {"Authorization": f"Bearer {self.access_token}"}
            params = {"fields": "user(emailAddress)"}
            res = requests.get(url, headers=headers, params=params, timeout=10)
            if res.status_code == 200:
                self.email = res.json().get("user", {}).get("emailAddress")
        except Exception:
            pass

    def get_valid_access_token(self):
        """Check if access token is valid, auto-refresh if expired."""
        if not self.refresh_token:
            raise ValueError("Google Drive is not authenticated. Please connect your account in settings.")
            
        # Refresh if expired or expiring in under 5 minutes
        if int(time.time()) + 300 >= self.expires_at:
            url = "https://oauth2.googleapis.com/token"
            payload = {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "refresh_token": self.refresh_token,
                "grant_type": "refresh_token"
            }
            res = requests.post(url, data=payload, timeout=10)
            res.raise_for_status()
            data = res.json()
            
            self.access_token = data.get("access_token")
            self.expires_at = int(time.time()) + int(data.get("expires_in", 3600))
            self.save_session()
            
        return self.access_token

    def list_files(self, folder_id="root"):
        """List folders and playable media files inside a parent folder."""
        token = self.get_valid_access_token()
        url = "https://www.googleapis.com/drive/v3/files"
        headers = {"Authorization": f"Bearer {token}"}
        
        # Query for items that are not trashed and belong to the parent folder
        query = f"'{folder_id}' in parents and trashed = false"
        params = {
            "q": query,
            "fields": "nextPageToken, files(id, name, mimeType, size, modifiedTime)",
            "pageSize": 1000,
            "supportsAllDrives": "true",
            "includeItemsFromAllDrives": "true"
        }
        
        res = requests.get(url, headers=headers, params=params, timeout=10)
        res.raise_for_status()
        
        files_data = res.json().get("files", [])
        
        folders = []
        playable_files = []
        
        # Extensions commonly playable in Kodi
        playable_extensions = (
            '.mp4', '.mkv', '.avi', '.flv', '.mov', '.wmv', '.mpg', '.mpeg', '.m4v',
            '.mp3', '.wav', '.flac', '.ogg', '.m4a', '.aac'
        )
        
        for f in files_data:
            mime = f.get("mimeType", "")
            name = f.get("name", "")
            
            if mime == "application/vnd.google-apps.folder":
                folders.append(f)
            else:
                name_lower = name.lower()
                if any(name_lower.endswith(ext) for ext in playable_extensions):
                    playable_files.append(f)
                    
        # Sort both lists alphabetically ascending
        folders.sort(key=lambda x: x.get("name", "").lower())
        playable_files.sort(key=lambda x: x.get("name", "").lower())
        
        return folders, playable_files

    def get_file_metadata(self, file_id):
        """Fetch metadata for a single file."""
        token = self.get_valid_access_token()
        url = f"https://www.googleapis.com/drive/v3/files/{file_id}"
        headers = {"Authorization": f"Bearer {token}"}
        params = {
            "fields": "id, name, mimeType, size",
            "supportsAllDrives": "true"
        }
        res = requests.get(url, headers=headers, params=params, timeout=10)
        res.raise_for_status()
        return res.json()
