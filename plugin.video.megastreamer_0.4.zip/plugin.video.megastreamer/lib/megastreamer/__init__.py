from urllib.parse import urlencode, urljoin
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from megastreamer.common import get_file_info
from megastreamer.service import main_service


def get_service_port(addon):
    port = xbmcgui.Window(10000).getProperty("megastreamer.port")
    if not port:
        # Wait up to 5 seconds for the background service to set the port
        for _ in range(50):
            xbmc.sleep(100)
            port = xbmcgui.Window(10000).getProperty("megastreamer.port")
            if port:
                break
    if not port:
        xbmc.log("[megastreamer] Background service port not found. Spinning up a local fallback service thread.", xbmc.LOGWARNING)
        try:
            web_thread = main_service(addon)
            port = str(web_thread.port)
        except Exception as e:
            xbmc.log(f"[megastreamer] Fallback service startup failed: {e}", xbmc.LOGERROR)
    return port


def init_and_play(mega_url, user_agent, listitem, plugin_handle, sid=None, proxy=None):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    addon = xbmcaddon.Addon(id="plugin.video.megastreamer")

    port = get_service_port(addon)
    if not port:
        xbmcgui.Dialog().notification("MegaStreamer", "Streaming-Service nicht aktiv.", xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    url = "http://127.0.0.1:" + port
    params = {"url": mega_url}
    if sid:
        params["sid"] = sid
    if proxy:
        params["proxy"] = proxy

    user_agent_encoded = urlencode({"User-Agent": user_agent})
    url = urljoin(url, f"/decrypt?{urlencode(params)}|{user_agent_encoded}")

    listitem.setPath(url)
    xbmcplugin.setResolvedUrl(plugin_handle, True, listitem)


def init_and_play_private(direct_url, key_hex, iv_hex, size, name, listitem, plugin_handle):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    addon = xbmcaddon.Addon(id="plugin.video.megastreamer")

    port = get_service_port(addon)
    if not port:
        xbmcgui.Dialog().notification("MegaStreamer", "Streaming-Service nicht aktiv.", xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    url = "http://127.0.0.1:" + port
    params = {
        "url": direct_url,
        "key": key_hex,
        "iv": iv_hex,
        "size": size,
        "name": name
    }

    user_agent_encoded = urlencode({"User-Agent": "Mozilla/5.0"})
    url = urljoin(url, f"/decrypt?{urlencode(params)}|{user_agent_encoded}")

    listitem.setPath(url)
    xbmcplugin.setResolvedUrl(plugin_handle, True, listitem)


def init_and_play_gdrive(file_id, name, listitem, plugin_handle):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    addon = xbmcaddon.Addon(id="plugin.video.megastreamer")

    port = get_service_port(addon)
    if not port:
        xbmcgui.Dialog().notification("MegaStreamer", "Streaming-Service nicht aktiv.", xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    url = "http://127.0.0.1:" + port
    params = {"file_id": file_id}

    user_agent_encoded = urlencode({"User-Agent": "Mozilla/5.0"})
    url = urljoin(url, f"/gdrive?{urlencode(params)}|{user_agent_encoded}")

    listitem.setPath(url)
    xbmcplugin.setResolvedUrl(plugin_handle, True, listitem)
