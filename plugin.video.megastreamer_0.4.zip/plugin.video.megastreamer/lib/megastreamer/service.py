import os
import sys

# Bootstrapping: Add parent lib folder to path to allow absolute imports when running as a service
_current_dir = os.path.dirname(os.path.abspath(__file__))
_parent_dir = os.path.dirname(_current_dir)
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)

import threading
import time
from random import randint
from re import match
from socketserver import ThreadingMixIn
from unicodedata import normalize
from wsgiref.simple_server import WSGIRequestHandler, WSGIServer, make_server

import requests
import xbmc
import xbmcvfs
import xbmcaddon
from bottle import default_app, hook, request, response, route
from Cryptodome.Cipher import AES
from Cryptodome.Util import Counter

from megastreamer.common import get_file_info

# Global variables for smart quota bypass and tracking
QUOTA_EXHAUSTED_TIME = 0.0
DIRECT_BYTES_DOWNLOADED = 0


# Global requests session to reuse TCP/TLS connections (Connection Keep-Alive)
session = requests.Session()


class SilentWSGIRequestHandler(WSGIRequestHandler):
    """Custom WSGI Request Handler with logging disabled"""

    protocol_version = "HTTP/1.1"

    def log_message(self, *args, **kwargs):
        """Disable log messages"""
        pass


class ThreadedWSGIServer(ThreadingMixIn, WSGIServer):
    """Multi-threaded WSGI server"""

    allow_reuse_address = True
    daemon_threads = True
    timeout = 1


@hook("before_request")
def set_server_header():
    response.set_header("Server", request.app.config["name"])


@route("/")
def index():
    response.content_type = "text/plain"
    return request.app.config["welcome_text"]


@route("/decrypt")
def decrypt():
    try:
        url = request.query.get("url")
        if not url:
            response.status = 400
            response.set_header("Content-Type", "text/plain")
            yield "Invalid URL"
        proxy = request.query.get("proxy")
        if proxy:
            proxy = {"http": proxy, "https": proxy}
        sid = request.query.get("sid")
        user_agent = request.headers.get("User-Agent")
        if not user_agent:
            response.status = 400
            response.set_header("Content-Type", "text/plain")
            yield "User-Agent header is missing"
        headers = {"User-Agent": user_agent}

        key_hex = request.query.get("key")
        iv_hex = request.query.get("iv")
        file_size = request.query.get("size")
        file_name = request.query.get("name")

        try:
            if key_hex and iv_hex and file_size:
                key = bytes.fromhex(key_hex)
                iv = bytes.fromhex(iv_hex)
                data = {
                    "g": url,
                    "s": int(file_size),
                    "at": {"n": file_name or "stream.bin"}
                }
            else:
                info = get_file_info(url, headers, sid, proxy)
                key = info["key"]
                iv = info["iv"]
                data = info["data"]
        except Exception as e:
            response.status = 400
            response.set_header("Content-Type", "text/plain")
            yield str(e)
            return

        url = data["g"]

        ext = data["at"]["n"].split(".")
        if len(ext) > 1:
            ext = ext[-1]
        else:
            ext = "bin"
        if ext == "bin":
            response.set_header("Content-Type", "application/octet-stream")
        elif ext in ["mp4", "webm", "mkv", "avi", "flv", "mov", "wmv", "mpg", "mpeg"]:
            response.set_header("Content-Type", f"video/{ext}")
        elif ext == "m4v":
            response.set_header("Content-Type", "video/mp4")
        elif ext in ["mp3", "wav", "flac", "ogg", "m4a", "wma", "aac"]:
            response.set_header("Content-Type", f"audio/{ext}")
        elif ext in ["jpg", "jpeg", "png", "gif", "bmp", "webp", "tiff"]:
            response.set_header("Content-Type", f"image/{ext}")
        else:
            response.set_header("Content-Type", "application/octet-stream")
        response.set_header(
            "Content-Disposition", f'attachment; filename="{data["at"]["n"]}"'
        )

        range_header = request.headers.get("Range")
        if range_header:
            match_range = match(r"bytes=(\d+)-(\d+)?", range_header)
            if match_range:
                start = int(match_range.group(1))
                end = int(match_range.group(2)) if match_range.group(2) else ""
                start_block_num = start // 16
                actual_start = start_block_num * 16
                headers["Range"] = f"bytes={actual_start}-{end}"
                response.set_header("Content-Range", f"bytes {start}-{end}/{data['s']}")
                response.set_header(
                    "Content-Length", int(data["s"]) - (start - actual_start)
                )
            else:
                yield "Invalid Range header"
        else:
            response.set_header("Content-Length", data["s"])
            start_block_num = 0

        # Get quota bypass settings
        addon = xbmcaddon.Addon()
        bypass_quota = False
        try:
            bypass_quota = addon.getSettingBool("bypass_quota")
        except Exception:
            try:
                bypass_quota = addon.getSetting("bypass_quota").lower() == "true"
            except Exception:
                bypass_quota = False

        cloudflare_worker_url = (addon.getSetting("cloudflare_worker_url") or "").strip()

        force_worker = False
        try:
            force_worker = addon.getSettingBool("force_worker")
        except Exception:
            try:
                force_worker = addon.getSetting("force_worker").lower() == "true"
            except Exception:
                force_worker = False

        global QUOTA_EXHAUSTED_TIME, DIRECT_BYTES_DOWNLOADED

        # If 6 hours have passed since last quota exhaustion, reset the byte counter to try direct download again
        if time.time() - QUOTA_EXHAUSTED_TIME >= 6 * 3600:
            if DIRECT_BYTES_DOWNLOADED > 0:
                xbmc.log("[megastreamer] 6 hours passed since last quota exhaustion or limit reached. Resetting byte counter to 0.", xbmc.LOGINFO)
                DIRECT_BYTES_DOWNLOADED = 0

        # Determine if we should use the Cloudflare Worker
        use_worker = False
        if bypass_quota and cloudflare_worker_url:
            if force_worker:
                use_worker = True
            elif time.time() - QUOTA_EXHAUSTED_TIME < 6 * 3600:
                use_worker = True
            elif DIRECT_BYTES_DOWNLOADED >= 4.9 * 1024 * 1024 * 1024:
                xbmc.log(f"[megastreamer] Proactively switching to Cloudflare Worker. Direct downloaded: {DIRECT_BYTES_DOWNLOADED / (1024**3):.2f} GB. Starting 6h cooldown.", xbmc.LOGINFO)
                QUOTA_EXHAUSTED_TIME = time.time()
                use_worker = True

        current_url = url
        current_proxy = proxy
        if use_worker:
            worker_url = cloudflare_worker_url.rstrip("/")
            xbmc.log(f"[megastreamer] Routing stream through Cloudflare Worker: {worker_url}", xbmc.LOGINFO)
            current_url = f"{worker_url}/{url}"
            current_proxy = None

        counter = Counter.new(
            128, initial_value=int.from_bytes(iv, byteorder="big") + start_block_num
        )
        cipher = AES.new(key, AES.MODE_CTR, counter=counter)
        
        if current_proxy:
            r2 = session.get(current_url, headers=headers, stream=True, proxies=current_proxy)
        else:
            r2 = session.get(current_url, headers=headers, stream=True)

        # Failsafe: if we tried directly and got HTTP 509 (Bandwidth Limit Exceeded), fallback to worker immediately
        if r2.status_code == 509 and not use_worker and bypass_quota and cloudflare_worker_url:
            # If we downloaded less than 100 MB directly in this session before getting blocked,
            # it indicates a continuation of a prior or external IP block.
            # In this case, set a short 30-minute retry cooldown instead of a full 6-hour cooldown.
            if DIRECT_BYTES_DOWNLOADED < 100 * 1024 * 1024:
                xbmc.log("[megastreamer] Direct request returned HTTP 509 quickly (<100MB direct). Setting a short 30-minute retry cooldown.", xbmc.LOGWARNING)
                QUOTA_EXHAUSTED_TIME = time.time() - (6 * 3600 - 30 * 60)
            else:
                xbmc.log("[megastreamer] Direct request returned HTTP 509 (Bandwidth Limit Exceeded). Falling back to Cloudflare Worker with 6h cooldown.", xbmc.LOGWARNING)
                QUOTA_EXHAUSTED_TIME = time.time()
                
            use_worker = True
            worker_url = cloudflare_worker_url.rstrip("/")
            current_url = f"{worker_url}/{url}"
            r2 = session.get(current_url, headers=headers, stream=True)

        if use_worker and r2.status_code not in (200, 206):
            if force_worker:
                xbmc.log("[megastreamer] Cloudflare Worker failed. Force worker is enabled; skipping fallback to direct IP to protect privacy.", xbmc.LOGERROR)
                import xbmcgui
                xbmcgui.Dialog().notification("MegaStreamer Error", "Cloudflare Worker fehlgeschlagen.", xbmcgui.NOTIFICATION_ERROR, 7000)
                if xbmc.Player().isPlaying():
                    xbmc.Player().stop()
                response.status = r2.status_code
                yield b""
                return
            else:
                xbmc.log(f"[megastreamer] Cloudflare Worker failed with status {r2.status_code}. Checking if direct IP recovered.", xbmc.LOGWARNING)
                if proxy:
                    r_direct = session.get(url, headers=headers, stream=True, proxies=proxy)
                else:
                    r_direct = session.get(url, headers=headers, stream=True)

                if r_direct.status_code in (200, 206):
                    xbmc.log("[megastreamer] Direct IP is available again! Switching back to direct download.", xbmc.LOGINFO)
                    r2 = r_direct
                    use_worker = False
                    QUOTA_EXHAUSTED_TIME = 0.0
                    DIRECT_BYTES_DOWNLOADED = 0
                else:
                    xbmc.log("[megastreamer] Both Cloudflare Worker and Direct IP are exhausted. Stopping playback.", xbmc.LOGERROR)
                    import xbmcgui
                    xbmcgui.Dialog().notification("MegaStreamer Limit", "Lokale IP & Cloudflare Limit erschöpft.", xbmcgui.NOTIFICATION_ERROR, 7000)
                    if xbmc.Player().isPlaying():
                        xbmc.Player().stop()
                    response.status = r2.status_code
                    yield b""
                    return

        response.status = r2.status_code

        first_chunk = True
        for chunk in r2.iter_content(chunk_size=256 * 1024):
            if not use_worker:
                DIRECT_BYTES_DOWNLOADED += len(chunk)
            if first_chunk and range_header:
                decrypted_chunk = cipher.decrypt(chunk)[start - actual_start :]
                first_chunk = False
            else:
                decrypted_chunk = cipher.decrypt(chunk)
            yield decrypted_chunk
    except Exception as e:
        import traceback

        traceback.print_exc()
        response.status = 500
        response.set_header("Content-Type", "text/plain")
        yield traceback.format_exc()


@route("/gdrive")
def gdrive():
    try:
        file_id = request.query.get("file_id")
        if not file_id:
            response.status = 400
            yield "Invalid file_id"
            return

        addon = xbmcaddon.Addon()
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        session_path = os.path.join(profile_path, 'gdrive_session.json')

        client_id = addon.getSetting("gdrive_client_id")
        secret_raw = addon.getSetting("gdrive_client_secret")
        client_secret = ""
        if secret_raw:
            if secret_raw.startswith("enc_"):
                try:
                    from megastreamer.crypto_utils import decrypt_password
                    client_secret = decrypt_password(secret_raw[4:])
                except Exception:
                    client_secret = secret_raw
            else:
                client_secret = secret_raw

        from megastreamer.gdrive import GoogleDriveClient
        client = GoogleDriveClient(client_id, client_secret, session_path)

        if not client.is_authenticated():
            response.status = 401
            yield "Google Drive not authenticated"
            return

        metadata = client.get_file_metadata(file_id)
        name = metadata.get("name", "stream.bin")
        size = int(metadata.get("size", 0))

        ext = name.split(".")[-1].lower() if "." in name else "bin"
        if ext in ["mp4", "webm", "mkv", "avi", "flv", "mov", "wmv", "mpg", "mpeg"]:
            response.set_header("Content-Type", f"video/{ext}")
        elif ext == "m4v":
            response.set_header("Content-Type", "video/mp4")
        elif ext in ["mp3", "wav", "flac", "ogg", "m4a", "aac"]:
            response.set_header("Content-Type", f"audio/{ext}")
        else:
            response.set_header("Content-Type", "application/octet-stream")

        response.set_header("Content-Disposition", f'attachment; filename="{name}"')

        token = client.get_valid_access_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "User-Agent": request.headers.get("User-Agent", "Mozilla/5.0")
        }

        range_header = request.headers.get("Range")
        if range_header:
            headers["Range"] = range_header
            match_range = match(r"bytes=(\d+)-(\d+)?", range_header)
            if match_range:
                start = int(match_range.group(1))
                end = int(match_range.group(2)) if match_range.group(2) else (size - 1)
                response.set_header("Content-Range", f"bytes {start}-{end}/{size}")
                response.set_header("Content-Length", end - start + 1)
                response.status = 206
        else:
            if size > 0:
                response.set_header("Content-Length", size)
            response.status = 200

        url = f"https://www.googleapis.com/drive/v3/files/{file_id}?alt=media"
        r = session.get(url, headers=headers, stream=True)
        
        if r.status_code == 401:
            token = client.get_valid_access_token()
            headers["Authorization"] = f"Bearer {token}"
            r = session.get(url, headers=headers, stream=True)

        response.status = r.status_code
        for chunk in r.iter_content(chunk_size=256 * 1024):
            yield chunk

    except Exception as e:
        import traceback
        response.status = 500
        yield traceback.format_exc()


class WebServerThread(threading.Thread):
    def __init__(self, httpd: WSGIServer, port: int):
        threading.Thread.__init__(self)
        self.web_killed = threading.Event()
        self.httpd = httpd
        self.port = port

    def run(self):
        while not self.web_killed.is_set():
            self.httpd.handle_request()

    def stop(self):
        self.web_killed.set()


def main_service(addon: xbmcaddon.Addon) -> WebServerThread:
    name = f"{addon.getAddonInfo('name')} v{addon.getAddonInfo('version')}"
    name = normalize("NFKD", name).encode("ascii", "ignore").decode("ascii")
    handle = f"[{name}]"
    app = default_app()
    welcome_text = f"{name} Web Service"
    app.config["name"] = name
    app.config["welcome_text"] = welcome_text
    try:
        minport = addon.getSettingInt("minport")
    except Exception:
        try:
            minport = int(addon.getSetting("minport") or "50000")
        except ValueError:
            minport = 50000

    try:
        maxport = addon.getSettingInt("maxport")
    except Exception:
        try:
            maxport = int(addon.getSetting("maxport") or "60000")
        except ValueError:
            maxport = 60000
    if minport > maxport or minport < 1024 or maxport > 65535:
        raise ValueError("Invalid port range")
    tries = 0
    while tries < 10:
        port = randint(minport, maxport)
        xbmc.log(f"{handle} Trying port {port} ({tries})...", xbmc.LOGINFO)
        try:
            httpd = make_server(
                addon.getSetting("webaddress"),
                port,
                app,
                server_class=ThreadedWSGIServer,
                handler_class=SilentWSGIRequestHandler,
            )
            break
        except OSError as e:
            tries += 1
            xbmc.log(
                f"{handle} Web service: port {port} already in use or error: {e}",
                xbmc.LOGERROR,
            )
    if tries == 10:
        xbmc.log(f"{handle} Web service: no available ports", xbmc.LOGERROR)
        raise OSError("No available ports")

    xbmc.log(f"{handle} Web service starting on port {port}", xbmc.LOGINFO)
    import xbmcgui
    xbmcgui.Window(10000).setProperty("megastreamer.port", str(port))

    web_thread = WebServerThread(httpd, port)
    web_thread.start()
    return web_thread


def update_advanced_settings(mb_size):
    import xml.etree.ElementTree as ET
    import xbmcgui
    
    path = xbmcvfs.translatePath("special://userdata/advancedsettings.xml")
    bytes_size = mb_size * 1024 * 1024
    
    root = None
    if os.path.exists(path):
        try:
            tree = ET.parse(path)
            root = tree.getroot()
        except Exception as e:
            xbmc.log(f"[megastreamer] Error parsing existing advancedsettings.xml: {e}. Recreating it.", xbmc.LOGWARNING)
            
    if root is None or root.tag != "advancedsettings":
        root = ET.Element("advancedsettings")
        
    cache = root.find("cache")
    if cache is None:
        cache = root.find("network")
        if cache is None:
            cache = ET.SubElement(root, "cache")
            
    # Clean up standard cache settings we manage
    for tag in ["memorysize", "buffermode", "readfactor", "cachemembc"]:
        elem = cache.find(tag)
        if elem is not None:
            cache.remove(elem)
            
    if bytes_size > 0:
        ms = ET.SubElement(cache, "memorysize")
        ms.text = str(bytes_size)
        
        bm = ET.SubElement(cache, "buffermode")
        bm.text = "1"
        
        rf = ET.SubElement(cache, "readfactor")
        rf.text = "6"
        
        xbmc.log(f"[megastreamer] Set cache memorysize={bytes_size}, buffermode=1, readfactor=6 in advancedsettings.xml", xbmc.LOGINFO)
    else:
        if len(cache) == 0:
            root.remove(cache)
        xbmc.log("[megastreamer] Cache custom size set to 0. Disabled custom buffer in advancedsettings.xml", xbmc.LOGINFO)
        
    try:
        from xml.dom import minidom
        xmlstr = minidom.parseString(ET.tostring(root)).toprettyxml(indent="    ")
        # Remove empty lines
        xmlstr = "\n".join([line for line in xmlstr.splitlines() if line.strip()])
        
        with open(path, "w", encoding="utf-8") as f:
            f.write(xmlstr)
            
        xbmcgui.Dialog().ok(
            "MegaStreamer Puffer",
            "Die Cache-Einstellungen wurden erfolgreich aktualisiert.\n"
            "Bitte starten Sie Kodi neu, damit die Änderungen wirksam werden."
        )
    except Exception as e:
        xbmc.log(f"[megastreamer] Error writing advancedsettings.xml: {e}", xbmc.LOGERROR)


class MegaStreamerMonitor(xbmc.Monitor):
    def __init__(self, addon):
        super().__init__()
        self.addon = addon
        self.last_cache_size = self.get_current_setting_cache_size()

    def get_current_setting_cache_size(self):
        try:
            return self.addon.getSettingInt("cache_size")
        except Exception:
            try:
                return int(self.addon.getSetting("cache_size") or "100")
            except ValueError:
                return 100

    def onSettingsChanged(self):
        current_size = self.get_current_setting_cache_size()
        if current_size != self.last_cache_size:
            xbmc.log(f"[megastreamer] Cache size setting changed from {self.last_cache_size}MB to {current_size}MB. Updating advancedsettings.xml...", xbmc.LOGINFO)
            self.last_cache_size = current_size
            update_advanced_settings(current_size)


if __name__ == "__main__":
    addon = xbmcaddon.Addon()
    monitor = MegaStreamerMonitor(addon)
    web_thread = main_service(addon)

    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
    if web_thread and web_thread.is_alive():
        web_thread.stop()
        try:
            web_thread.join()
        except RuntimeError:
            pass
    xbmc.log(f"[{addon.getAddonInfo('name')}] Web service stopped", xbmc.LOGINFO)
