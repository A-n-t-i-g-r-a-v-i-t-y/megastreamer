import base64
import hashlib
from Cryptodome.Cipher import AES

# Derive a 256-bit key from a fixed identifier
SECRET_KEY = hashlib.sha256(b"megastreamerAddonPasswordObfuscationSecretKey").digest()

def encrypt_password(password: str) -> str:
    """Encrypt a plaintext password string to a base64 encrypted format."""
    if not password:
        return ""
    # Create AES CBC cipher with auto-generated IV
    cipher = AES.new(SECRET_KEY, AES.MODE_CBC)
    iv = cipher.iv
    
    # Custom PKCS7 padding
    data_bytes = password.encode("utf-8")
    pad_len = AES.block_size - (len(data_bytes) % AES.block_size)
    padded_data = data_bytes + bytes([pad_len] * pad_len)
    
    encrypted = cipher.encrypt(padded_data)
    # Combine IV and encrypted data, and encode as base64
    combined = iv + encrypted
    return base64.b64encode(combined).decode("utf-8")

def decrypt_password(encrypted_b64: str) -> str:
    """Decrypt a base64 encrypted password string to plaintext."""
    if not encrypted_b64:
        return ""
    try:
        combined = base64.b64decode(encrypted_b64.encode("utf-8"))
        if len(combined) < AES.block_size:
            return encrypted_b64
        iv = combined[:AES.block_size]
        encrypted = combined[AES.block_size:]
        cipher = AES.new(SECRET_KEY, AES.MODE_CBC, iv)
        decrypted_padded = cipher.decrypt(encrypted)
        
        # Custom PKCS7 unpadding
        pad_len = decrypted_padded[-1]
        if pad_len < 1 or pad_len > AES.block_size:
            return encrypted_b64
        decrypted = decrypted_padded[:-pad_len]
        return decrypted.decode("utf-8")
    except Exception:
        # Fallback to returning the input string if decryption fails
        return encrypted_b64
