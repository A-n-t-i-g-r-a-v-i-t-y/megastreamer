import json
import os
import struct
import sys
from urllib.parse import parse_qsl

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from megastreamer import get_file_info, init_and_play, init_and_play_private
from megastreamer.mega import MegaClient, MegaSessionExpiredException
from megastreamer.crypto_utils import encrypt_password, decrypt_password


def show_error(title, message):
    xbmcgui.Dialog().ok(title, message)


def get_session_file_path(addon):
    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not xbmcvfs.exists(profile_path):
        xbmcvfs.mkdir(profile_path)
    return os.path.join(profile_path, 'session.json')


def load_cached_session(addon, email):
    session_file = get_session_file_path(addon)
    if os.path.exists(session_file):
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if data.get("email") == email.lower() and data.get("sid") and data.get("master_key"):
                return data
        except Exception as e:
            xbmc.log(f"[megastreamer] Error loading session cache: {e}", xbmc.LOGERROR)
    return None


def save_cached_session(addon, email, client):
    session_file = get_session_file_path(addon)
    try:
        session_data = client.dump_session()
        session_data["email"] = email.lower()
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session_data, f)
    except Exception as e:
        xbmc.log(f"[megastreamer] Error saving session cache: {e}", xbmc.LOGERROR)


def clear_cached_session(addon):
    session_file = get_session_file_path(addon)
    if os.path.exists(session_file):
        try:
            os.remove(session_file)
        except Exception as e:
            xbmc.log(f"[megastreamer] Error clearing session cache: {e}", xbmc.LOGERROR)


def get_mega_client(addon, email, password):
    client = MegaClient(email, password)
    cached = load_cached_session(addon, email)
    if cached:
        xbmc.log("[megastreamer] Using cached session ID.", xbmc.LOGINFO)
        client.load_session(cached["sid"], cached["master_key"], cached.get("root_id"))
    else:
        xbmc.log("[megastreamer] No cached session, performing fresh login.", xbmc.LOGINFO)
        if not client.login():
            raise ValueError("Login fehlgeschlagen. Bitte prüfe deine E-Mail und dein Passwort.")
        save_cached_session(addon, email, client)
    return client


if __name__ == "__main__":
    addon = xbmcaddon.Addon(id="plugin.video.megastreamer")
    plugin_url = sys.argv[0]
    plugin_handle = int(sys.argv[1])
    
    # Parse URL parameters
    params = dict(parse_qsl(sys.argv[2].replace("?", "")))
    action = params.get("action")

    if action == "play":
        # Original public URL playback flow
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        mega_url = params.get("url")
        if not mega_url:
            raise ValueError("Missing 'url' parameter")
        user_agent = params.get("user_agent")
        if not user_agent:
            raise ValueError("Missing 'user_agent' parameter")
        sid = params.get("sid")
        proxy = params.get("proxy")
        info = get_file_info(mega_url, {"User-Agent": user_agent}, sid=sid, proxy=proxy)
        listitem = xbmcgui.ListItem(info["data"]["at"]["n"])
        init_and_play(mega_url, user_agent, listitem=listitem, sid=sid, proxy=proxy)

    elif action == "play_private":
        # Private account file playback flow
        file_id = params.get("file_id")
        if not file_id:
            show_error("megastreamer Error", "Missing file ID.")
            sys.exit(0)

        email = addon.getSetting("megaemail")
        password_raw = addon.getSetting("megapassword")

        if not email or not password_raw:
            show_error("megastreamer", "Bitte trage deine Mega.nz E-Mail und dein Passwort in den Addon-Einstellungen ein.")
            addon.openSettings()
            sys.exit(0)

        # Transparently encrypt if user just set plain text
        if password_raw.startswith("enc_"):
            password = decrypt_password(password_raw[4:])
        else:
            password = password_raw
            addon.setSetting("megapassword", "enc_" + encrypt_password(password))

        # Show busy indicator
        xbmc.executebuiltin("ActivateWindow(busydialog)")

        try:
            try:
                client = get_mega_client(addon, email, password)
                files = client.get_files()
                if file_id not in files:
                    raise ValueError("Die Datei wurde nicht auf deinem Mega-Konto gefunden.")
                file_node = files[file_id]
                direct_link_data = client.get_download_link(file_id)
            except MegaSessionExpiredException:
                xbmc.log("[megastreamer] Session expired in play_private. Retrying with fresh login...", xbmc.LOGINFO)
                clear_cached_session(addon)
                client = get_mega_client(addon, email, password)
                files = client.get_files()
                if file_id not in files:
                    raise ValueError("Die Datei wurde nicht auf deinem Mega-Konto gefunden.")
                file_node = files[file_id]
                direct_link_data = client.get_download_link(file_id)

            # Update cache to save root_id if loaded
            save_cached_session(addon, email, client)

            # Package keys to pass to the decrypt server
            key_hex = struct.pack('!4I', *file_node['k']).hex()
            iv_hex = struct.pack('!4I', *file_node['iv']).hex()

            xbmc.executebuiltin("Dialog.Close(busydialog)")

            listitem = xbmcgui.ListItem(file_node['a']['n'])
            init_and_play_private(
                direct_url=direct_link_data['g'],
                key_hex=key_hex,
                iv_hex=iv_hex,
                size=direct_link_data['s'],
                name=file_node['a']['n'],
                listitem=listitem
            )
        except Exception as e:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            show_error("megastreamer Error", str(e))

    else:
        # Private account files directory listing flow (action is None or "list")
        email = addon.getSetting("megaemail")
        password_raw = addon.getSetting("megapassword")

        if not email or not password_raw:
            show_error("megastreamer", "Bitte trage deine Mega.nz E-Mail und dein Passwort in den Addon-Einstellungen ein.")
            addon.openSettings()
            # Finish empty directory listing
            xbmcplugin.endOfDirectory(plugin_handle, False)
        else:
            # Transparently encrypt if user just set plain text
            if password_raw.startswith("enc_"):
                password = decrypt_password(password_raw[4:])
            else:
                password = password_raw
                addon.setSetting("megapassword", "enc_" + encrypt_password(password))

            xbmc.executebuiltin("ActivateWindow(busydialog)")
            try:
                try:
                    client = get_mega_client(addon, email, password)
                    files = client.get_files()
                except MegaSessionExpiredException:
                    xbmc.log("[megastreamer] Session expired in list. Retrying with fresh login...", xbmc.LOGINFO)
                    clear_cached_session(addon)
                    client = get_mega_client(addon, email, password)
                    files = client.get_files()

                # Update cache to save root_id if loaded
                save_cached_session(addon, email, client)

                xbmc.executebuiltin("Dialog.Close(busydialog)")

                folder_id = params.get("folder_id")
                if not folder_id:
                    folder_id = client.root_id



                # List folders first, then media files
                for handle, node in files.items():
                    if node.get('p') == folder_id:
                        # 1. Folders
                        if node['t'] == 1:
                            url = f"{plugin_url}?action=list&folder_id={handle}"
                            listitem = xbmcgui.ListItem(label=node['a']['n'])
                            # Set folder icon / art
                            listitem.setArt({'icon': 'DefaultFolder.png'})
                            xbmcplugin.addDirectoryItem(
                                handle=plugin_handle,
                                url=url,
                                listitem=listitem,
                                isFolder=True
                            )
                        # 2. Files
                        elif node['t'] == 0:
                            name = node['a']['n'].lower()
                            extensions = [
                                '.mp4', '.mkv', '.avi', '.flv', '.mov', '.wmv', '.mpg', '.mpeg', '.m4v',
                                '.mp3', '.wav', '.flac', '.ogg', '.m4a', '.aac'
                            ]
                            if any(name.endswith(ext) for ext in extensions):
                                url = f"{plugin_url}?action=play_private&file_id={handle}"
                                listitem = xbmcgui.ListItem(label=node['a']['n'])
                                listitem.setProperty("IsPlayable", "true")
                                listitem.setArt({'icon': 'DefaultVideo.png'})
                                xbmcplugin.addDirectoryItem(
                                    handle=plugin_handle,
                                    url=url,
                                    listitem=listitem,
                                    isFolder=False
                                )

                # Enable standard Kodi UI features
                xbmcplugin.setContent(plugin_handle, 'videos')
                xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_LABEL)
                xbmcplugin.endOfDirectory(plugin_handle, True)

            except Exception as e:
                xbmc.executebuiltin("Dialog.Close(busydialog)")
                show_error("megastreamer Error", str(e))
                xbmcplugin.endOfDirectory(plugin_handle, False)

