from urllib.parse import urlencode, urljoin

import xbmc
import xbmcaddon

from .common import get_file_info
from .service import main_service


def init_and_play(mega_url, user_agent, listitem, sid=None, proxy=None):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    monitor = xbmc.Monitor()
    addon = xbmcaddon.Addon(id="plugin.video.megastreamer")

    web_thread = main_service(addon)

    url = "http://127.0.0.1:" + str(web_thread.port)
    params = {"url": mega_url}
    if sid:
        params["sid"] = sid
    if proxy:
        params["proxy"] = proxy

    user_agent_encoded = urlencode({"User-Agent": user_agent})

    url = urljoin(url, f"/decrypt?{urlencode(params)}|{user_agent_encoded}")

    player = xbmc.Player()
    listitem.setPath(url)
    player.play(url, listitem)

    # Let the player start
    xbmc.sleep(2000)

    while player.isPlaying() and not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break

    if web_thread and web_thread.is_alive():
        web_thread.stop()
        try:
            web_thread.join()
        except RuntimeError:
            pass
    xbmc.log(
        f"[{addon.getAddonInfo('name')}] Web service stopped on port {web_thread.port}",
        xbmc.LOGINFO,
    )


def init_and_play_private(direct_url, key_hex, iv_hex, size, name, listitem):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    monitor = xbmc.Monitor()
    addon = xbmcaddon.Addon(id="plugin.video.megastreamer")

    web_thread = main_service(addon)

    url = "http://127.0.0.1:" + str(web_thread.port)
    params = {
        "url": direct_url,
        "key": key_hex,
        "iv": iv_hex,
        "size": size,
        "name": name
    }

    user_agent_encoded = urlencode({"User-Agent": "Mozilla/5.0"})

    url = urljoin(url, f"/decrypt?{urlencode(params)}|{user_agent_encoded}")

    player = xbmc.Player()
    listitem.setPath(url)
    player.play(url, listitem)

    # Let the player start
    xbmc.sleep(2000)

    while player.isPlaying() and not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break

    if web_thread and web_thread.is_alive():
        web_thread.stop()
        try:
            web_thread.join()
        except RuntimeError:
            pass
    xbmc.log(
        f"[{addon.getAddonInfo('name')}] Web service stopped on port {web_thread.port}",
        xbmc.LOGINFO,
    )

