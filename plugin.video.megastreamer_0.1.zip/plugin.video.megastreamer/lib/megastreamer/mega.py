import base64
import binascii
import hashlib
import json
import math
import random
import re
import struct
from Cryptodome.Cipher import AES

MEGA_API = "https://g.api.mega.co.nz/cs"

# --- Cryptographic Helpers ---

def aes_cbc_encrypt(data, key):
    aes_cipher = AES.new(key, AES.MODE_CBC, b'\0' * 16)
    return aes_cipher.encrypt(data)


def aes_cbc_decrypt(data, key):
    aes_cipher = AES.new(key, AES.MODE_CBC, b'\0' * 16)
    return aes_cipher.decrypt(data)


def aes_cbc_encrypt_a32(data, key):
    return str_to_a32(aes_cbc_encrypt(a32_to_str(data), a32_to_str(key)))


def aes_cbc_decrypt_a32(data, key):
    return str_to_a32(aes_cbc_decrypt(a32_to_str(data), a32_to_str(key)))


def stringhash(email_str, aeskey):
    s32 = str_to_a32(email_str)
    h32 = [0, 0, 0, 0]
    for i in range(len(s32)):
        h32[i % 4] ^= s32[i]
    for r in range(0x4000):
        h32 = aes_cbc_encrypt_a32(h32, aeskey)
    return a32_to_base64((h32[0], h32[2]))


def prepare_key(arr):
    pkey = [0x93C467E3, 0x7DB0C7A4, 0xD1BE3F81, 0x0152CB56]
    for r in range(0x10000):
        for j in range(0, len(arr), 4):
            key = [0, 0, 0, 0]
            for i in range(4):
                if i + j < len(arr):
                    key[i] = arr[i + j]
            pkey = aes_cbc_encrypt_a32(pkey, key)
    return pkey


def encrypt_key(a, key):
    return sum((aes_cbc_encrypt_a32(a[i:i + 4], key)
                for i in range(0, len(a), 4)), ())


def decrypt_key(a, key):
    return sum((aes_cbc_decrypt_a32(a[i:i + 4], key)
                for i in range(0, len(a), 4)), ())


def decrypt_attr(attr, key):
    attr = aes_cbc_decrypt(attr, a32_to_str(key))
    # Strip null padding
    attr = attr.rstrip(b'\0')
    try:
        # Check for MEGA prefix
        if attr.startswith(b'MEGA{"'):
            return json.loads(attr[4:].decode('utf-8', errors='ignore'))
        # Try raw json decode as fallback
        attr_str = attr.decode('utf-8', errors='ignore')
        if attr_str.startswith('MEGA'):
            return json.loads(attr_str[4:])
    except Exception:
        pass
    return False


def a32_to_str(a):
    return struct.pack('>%dI' % len(a), *a)


def str_to_a32(b):
    if isinstance(b, str):
        b = b.encode('latin1')
    if len(b) % 4:
        # pad to multiple of 4
        b += b'\0' * (4 - len(b) % 4)
    return struct.unpack('>%dI' % (len(b) / 4), b)


def mpi_to_int(s):
    return int(binascii.hexlify(s[2:]), 16)


def base64_url_decode(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    data += b'=='[(2 - len(data) * 3) % 4:]
    data = data.replace(b'-', b'+').replace(b'_', b'/').replace(b',', b'')
    return base64.b64decode(data)


def base64_to_a32(s):
    return str_to_a32(base64_url_decode(s))


def base64_url_encode(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    data = base64.b64encode(data)
    data = data.decode('utf-8').replace('+', '-').replace('/', '_').replace('=', '')
    return data


def a32_to_base64(a):
    return base64_url_encode(a32_to_str(a))


# --- MegaClient Implementation ---

class MegaSessionExpiredException(Exception):
    """Custom exception raised when Mega session is invalid or expired."""
    pass


class MegaClient:
    def __init__(self, email, password):
        self.email = email.lower()
        self.password = password
        self.sid = None
        self.master_key = None
        self.root_id = None
        self.sequence_num = random.randint(0, 0xFFFFFFFF)

    def load_session(self, sid, master_key, root_id=None):
        self.sid = sid
        self.master_key = tuple(master_key) if isinstance(master_key, list) else master_key
        self.root_id = root_id

    def dump_session(self):
        return {
            "sid": self.sid,
            "master_key": list(self.master_key) if self.master_key else None,
            "root_id": self.root_id
        }

    def login(self):
        # 1. Get user salt (determines V1 or V2 account)
        salt_resp = self._api_request({'a': 'us0', 'user': self.email})
        user_salt = None
        try:
            user_salt = base64_to_a32(salt_resp['s'])
        except KeyError:
            # V1 user account
            password_aes = prepare_key(str_to_a32(self.password))
            user_hash = stringhash(self.email, password_aes)
        else:
            # V2 user account
            pbkdf2_key = hashlib.pbkdf2_hmac(
                hash_name='sha512',
                password=self.password.encode('utf-8'),
                salt=a32_to_str(user_salt),
                iterations=100000,
                dklen=32
            )
            password_aes = str_to_a32(pbkdf2_key[:16])
            user_hash = base64_url_encode(pbkdf2_key[-16:])

        # 2. Authenticate
        resp = self._api_request({'a': 'us', 'user': self.email, 'uh': user_hash})
        if isinstance(resp, int) and resp < 0:
            raise ValueError(f"Authentication failed with error code: {resp}")

        # 3. Decrypt Master Key
        encrypted_master_key = base64_to_a32(resp['k'])
        self.master_key = decrypt_key(encrypted_master_key, password_aes)

        # 4. Decrypt Session ID (sid)
        if 'tsid' in resp:
            tsid = base64_url_decode(resp['tsid'])
            key_encrypted = a32_to_str(encrypt_key(str_to_a32(tsid[:16]), self.master_key))
            if key_encrypted == tsid[-16:]:
                self.sid = resp['tsid']
        elif 'csid' in resp:
            encrypted_rsa_private_key = base64_to_a32(resp['privk'])
            rsa_private_key = decrypt_key(encrypted_rsa_private_key, self.master_key)

            private_key = a32_to_str(rsa_private_key)
            rsa_private_key = [0, 0, 0, 0]
            for i in range(4):
                bitlength = (private_key[0] * 256) + private_key[1]
                bytelength = math.ceil(bitlength / 8)
                bytelength += 2
                rsa_private_key[i] = mpi_to_int(private_key[:bytelength])
                private_key = private_key[bytelength:]

            first_factor_p = rsa_private_key[0]
            second_factor_q = rsa_private_key[1]
            private_exponent_d = rsa_private_key[2]
            rsa_modulus_n = first_factor_p * second_factor_q

            encrypted_sid = mpi_to_int(base64_url_decode(resp['csid']))
            # Pure-Python raw RSA private key decryption: m = c^d mod n
            sid_num = pow(encrypted_sid, private_exponent_d, rsa_modulus_n)
            sid_hex = '%x' % sid_num
            sid_bytes = binascii.unhexlify('0' + sid_hex if len(sid_hex) % 2 else sid_hex)
            self.sid = base64_url_encode(sid_bytes[:43])

        return self.sid is not None

    def _api_request(self, data):
        params = {'id': self.sequence_num}
        self.sequence_num += 1

        if self.sid:
            params['sid'] = self.sid

        if not isinstance(data, list):
            data = [data]

        import requests
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            "Origin": "https://mega.nz",
            "Referer": "https://mega.nz/",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept": "*/*"
        }
        response = requests.post(
            MEGA_API,
            params=params,
            json=data,
            headers=headers,
            timeout=30
        )
        try:
            json_resp = response.json()
        except ValueError:
            text_preview = response.text[:200] if response.text else "Leere Server-Antwort"
            raise ValueError(
                f"Mega API antwortete mit ungültigen Daten (Status {response.status_code}): {text_preview}"
            )

        resp = json_resp[0] if isinstance(json_resp, list) else json_resp
        if isinstance(resp, int) and resp < 0:
            if resp == -9:
                raise MegaSessionExpiredException("Mega Session Expired or Invalid (Error -9)")
        return resp


    def get_files(self):
        files = self._api_request({'a': 'f', 'c': 1, 'r': 1})
        if not isinstance(files, dict) or 'f' not in files:
            return {}

        files_dict = {}
        shared_keys = {}

        # Initialize shared keys
        ok_dict = {}
        if 'ok' in files:
            for ok_item in files['ok']:
                shared_key = decrypt_key(base64_to_a32(ok_item['k']), self.master_key)
                ok_dict[ok_item['h']] = shared_key
        if 's' in files:
            for s_item in files['s']:
                if s_item['u'] not in shared_keys:
                    shared_keys[s_item['u']] = {}
                if s_item['h'] in ok_dict:
                    shared_keys[s_item['u']][s_item['h']] = ok_dict[s_item['h']]

        for file in files['f']:
            # Process & decrypt node
            if file['t'] == 0 or file['t'] == 1:
                keys = dict(
                    keypart.split(':', 1) for keypart in file['k'].split('/')
                    if ':' in keypart
                )
                uid = file['u']
                key = None
                # Owned objects
                if uid in keys:
                    key = decrypt_key(base64_to_a32(keys[uid]), self.master_key)
                # Shared folders
                elif 'su' in file and 'sk' in file and ':' in file['k']:
                    shared_key = decrypt_key(base64_to_a32(file['sk']), self.master_key)
                    key = decrypt_key(base64_to_a32(keys[file['h']]), shared_key)
                    if file['su'] not in shared_keys:
                        shared_keys[file['su']] = {}
                    shared_keys[file['su']][file['h']] = shared_key
                # Shared files
                elif file['u'] and file['u'] in shared_keys:
                    for hkey in shared_keys[file['u']]:
                        shared_key = shared_keys[file['u']][hkey]
                        if hkey in keys:
                            key = keys[hkey]
                            key = decrypt_key(base64_to_a32(key), shared_key)
                            break

                if key is not None:
                    if file['t'] == 0:
                        # File: extract AES key and IV
                        k = (key[0] ^ key[4], key[1] ^ key[5], key[2] ^ key[6], key[3] ^ key[7])
                        file['iv'] = key[4:6] + (0, 0)
                        file['meta_mac'] = key[6:8]
                    else:
                        # Folder
                        k = key
                    file['key'] = key
                    file['k'] = k
                    attributes = base64_url_decode(file['a'])
                    attributes = decrypt_attr(attributes, k)
                    file['a'] = attributes
                else:
                    file['a'] = False
            elif file['t'] == 2:
                self.root_id = file['h']
                file['a'] = {'n': 'Cloud Drive'}
            elif file['t'] == 3:
                file['a'] = {'n': 'Inbox'}
            elif file['t'] == 4:
                file['a'] = {'n': 'Rubbish Bin'}

            if file['a']:
                files_dict[file['h']] = file

        return files_dict

    def get_download_link(self, file_handle):
        # Calls the 'g' method to retrieve direct stream URL and size
        resp = self._api_request({'a': 'g', 'g': 1, 'n': file_handle})
        if isinstance(resp, dict) and 'g' in resp:
            return resp
        raise ValueError("Could not retrieve file download link from Mega API.")
